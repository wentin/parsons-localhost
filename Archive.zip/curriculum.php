<?php
error_reporting(E_ALL);
include_once('simple_html_dom.php');

$program = $_POST['program'];

$html = file_get_html('http://www.newschool.edu/parsons/' . $program . '/');
//$html = file_get_html('youtube.htm');
//$html = file_get_html('Product.ibatis.xml');
foreach($html->find('.tablecloth') as $element) 
       echo $element->outertext;
foreach($html->find('.total') as $element) 
       echo $element->outertext;

?>